import{mn as e}from"./chakra-CyEqUBJ-.js";import{n as t,o as n}from"./i18n-iY-5p6t_.js";import{t as r}from"./document-Bjey4wcY.js";var i=`Last updated: July 18, 2026

1. GENERAL PROVISIONS

1.1. This Privacy Policy (hereinafter referred to as the "Policy") defines the procedure for processing and protecting the personal data of users of the MUSOR DROP website (hereinafter referred to as the "Website", the "Service").

1.2. By using the Website, you consent to the processing of your personal data in accordance with this Policy.

2. DATA COLLECTED

2.1. When using the Service, the following data may be collected: identifiers of third-party service accounts used for authorization (Steam, Telegram, Google); username and avatar; email address; IP address, browser and device data; information about transactions performed on the Website.

2.2. The Website uses cookies and similar technologies to ensure the operation of the Service, analyze traffic, and improve the quality of service.

3. PURPOSES OF DATA PROCESSING

3.1. Personal data is processed for the purposes of: providing access to the Service's features; processing payments and withdrawals; communicating with the user regarding the operation of the Service; preventing fraud and ensuring security; complying with legal requirements.

4. DATA SHARING WITH THIRD PARTIES

4.1. Personal data is not shared with third parties, except in cases of: payment processing by payment systems; compliance with legal requirements; protection of the rights and legitimate interests of the Administration.

5. DATA STORAGE AND PROTECTION

5.1. The Administration takes the necessary organizational and technical measures to protect personal data from unauthorized access, alteration, disclosure, or destruction.

5.2. Personal data is stored no longer than necessary for the purposes of its processing, or for the period established by law.

6. USER RIGHTS

6.1. The user has the right to: request information about the personal data being processed; demand the correction, blocking, or deletion of their data; withdraw consent to the processing of personal data.

6.2. To exercise their rights, the user may contact customer support at: support@musor.win.

7. CHANGES TO THE POLICY

7.1. The Administration has the right to make changes to this Policy. The new version comes into force upon its publication on the Website.
`,a=`Дата последнего обновления: 18 июля 2026 года

1. ОБЩИЕ ПОЛОЖЕНИЯ

1.1. Настоящая Политика конфиденциальности (далее — «Политика») определяет порядок обработки и защиты персональных данных пользователей сайта MUSOR DROP (далее — «Сайт», «Сервис»).

1.2. Используя Сайт, вы даёте согласие на обработку ваших персональных данных в соответствии с настоящей Политикой.

2. СОБИРАЕМЫЕ ДАННЫЕ

2.1. При использовании Сервиса могут собираться следующие данные: идентификаторы аккаунтов сторонних сервисов, используемых для авторизации (Steam, Telegram, Google); имя пользователя и аватар; адрес электронной почты; IP-адрес, данные о браузере и устройстве; сведения об операциях, совершённых на Сайте.

2.2. Сайт использует файлы cookie и аналогичные технологии для обеспечения работы Сервиса, анализа посещаемости и улучшения качества обслуживания.

3. ЦЕЛИ ОБРАБОТКИ ДАННЫХ

3.1. Персональные данные обрабатываются в целях: предоставления доступа к функциям Сервиса; обработки платежей и вывода средств; связи с пользователем по вопросам работы Сервиса; предотвращения мошенничества и обеспечения безопасности; исполнения требований законодательства.

4. ПЕРЕДАЧА ДАННЫХ ТРЕТЬИМ ЛИЦАМ

4.1. Персональные данные не передаются третьим лицам, за исключением случаев: обработки платежей платёжными системами; исполнения требований законодательства; защиты прав и законных интересов Администрации.

5. ХРАНЕНИЕ И ЗАЩИТА ДАННЫХ

5.1. Администрация принимает необходимые организационные и технические меры для защиты персональных данных от несанкционированного доступа, изменения, раскрытия или уничтожения.

5.2. Персональные данные хранятся не дольше, чем это необходимо для целей их обработки, либо в течение срока, установленного законодательством.

6. ПРАВА ПОЛЬЗОВАТЕЛЯ

6.1. Пользователь вправе: запросить сведения об обрабатываемых персональных данных; потребовать уточнения, блокирования или удаления своих данных; отозвать согласие на обработку персональных данных.

6.2. Для реализации своих прав пользователь может обратиться в службу поддержки по адресу: support@musor.win.

7. ИЗМЕНЕНИЕ ПОЛИТИКИ

7.1. Администрация вправе вносить изменения в настоящую Политику. Новая редакция вступает в силу с момента её публикации на Сайте.
`,o=e();function s(){let{t:e}=t(),{language:s}=n();return(0,o.jsx)(r,{title:e(`footer.privacy_policy`),text:s===`ru`?a:i})}export{s as default};