import{mn as e}from"./chakra-CyEqUBJ-.js";import{n as t,o as n}from"./i18n-iY-5p6t_.js";import{t as r}from"./document-Bjey4wcY.js";var i=`Last updated: July 18, 2026

This User Agreement (hereinafter referred to as the "Agreement") governs the relationship between the administration of the website musor.win — MUSOR DROP (hereinafter referred to as the "Administration", the "Owner") and any individual using this Website and its software tools (hereinafter referred to as the "User"). Familiarization with this Agreement, registration, and use of the Website's functionality mean the User's full acceptance of the terms of this Agreement.

1. GENERAL PROVISIONS

1.1. This User Agreement (hereinafter referred to as the "Agreement") governs the relationship between the administration of the website musor.win — MUSOR DROP (hereinafter referred to as the "Administration", the "Owner") and any individual using this Website and its software tools (hereinafter referred to as the "User"). Familiarization with this Agreement, registration, and use of the Website's functionality indicate the User's full acceptance of the terms of this Agreement.

1.2. The website musor.win is not affiliated with Valve Corporation or the Steam platform.

1.3. To use the Website, authorization through one of the supported methods (Steam, Telegram, VK, Google) is required. Registration and actions of the User are carried out under their personal responsibility.

1.4. Use of the Website by persons under 18 years of age is prohibited.

1.5. The Administration reserves the right to modify this Agreement at any time without prior notice. The current version is published on the Website.

2. PERSONAL ACCOUNT AND BALANCE

2.1. After authorization, a personal account is created, which displays the current balance, transaction history, and access to the platform's features.

2.2. Balance top-up is available through authorized payment services. The platform does not store users' payment data.

2.3. The balance is expressed in conventional units and is not real currency. It can be used exclusively within the platform for purchases, upgrades, contracts, and participation in raffles.

2.4. Using the balance signifies the User's full agreement with the terms of receipt and processing of goods/services.

3. PURCHASE AND USE OF ITEMS

3.1. Items are purchased using the internal balance.

3.2. All purchases are considered final; refunds are not possible after the item has been activated or received.

3.3. Items are withdrawn via an API bot on Steam using the trade link specified by the User in their personal account.

3.4. In order to withdraw items acquired using funds deposited to the balance, the User must perform in-game actions (bets, upgrades, contracts, and other operations provided by the Website's functionality) in an amount not less than the amount of the corresponding balance top-up.

The minimum wagering requirement applies to each balance top-up separately and is calculated within each individual top-up;
When the User makes a new balance top-up, the corresponding amount is added to the total required wagering amount;
Until the minimum wagering requirement is fulfilled, the withdrawal of items, exchange, or any other extraction of value from the platform may be restricted.

4. REFUNDS

4.1. A refund is possible only if all of the following conditions are met simultaneously:

the funds were deposited into the balance but not used (i.e., not spent on in-game functions, including purchases, upgrades, contracts, raffles, etc.);
no more than 14 calendar days have passed since the top-up;
the User initiates the refund through the established procedure, including passing verification.

4.2. The platform reserves the right to deny a refund if:

funds were fully or partially used;
signs of violation of platform rules are detected;
the request is submitted anonymously or without identity confirmation.

4.3. To submit a refund request, the User must:

contact customer support through the communication channel specified on the Website;
provide proof of payment (receipt, statement, transaction ID);
complete the identity verification process (ID verification and, upon request, proof of ownership of the payment method);
wait for a written response from the Administration (within 10 business days).

4.4. Refunds are issued only to the same payment method used for the original transaction. Refunds to third-party accounts or other profiles are not allowed.

4.5. If the User deposits funds and then initiates a refund without valid grounds (e.g., for the purpose of fraud or system manipulation), the Administration has the right to:

block the account without refunding the remaining balance;
report the User to the payment system for blacklisting;
notify the relevant authorities in case of suspected fraud.

4.6. Transactions involving bonus funds, promo codes, gifts, and cashback are not eligible for a refund. Such funds are considered spent upon being credited.

4.7. In the event of technical errors (e.g., double charge, API failure), the User must contact support within 72 hours. Upon review, funds may be fully refunded or the balance manually restored.

5. RESTRICTIONS AND PROHIBITIONS

5.1. Users are prohibited from engaging in actions that violate the platform's technical, legal, and ethical standards. In particular, the following are strictly forbidden:

creating and using more than one account (multi-accounting);
sharing account credentials (login, password) with third parties;
using Steam accounts not registered in the User's own name;
accessing the platform via VPN/proxy, IP spoofing, or other location-masking methods without prior permission from the Administration;
attempting to bypass blocks, sanctions, limits, or regional restrictions.

5.2. Any attempt to interfere with the Website's functionality is prohibited, including:

using scripts, bots, auto-clickers, plugins, proxy servers, extensions, or third-party software;
hacking, modifying, or decompiling the platform's code;
exploiting bugs, errors, or vulnerabilities for personal gain;
sending mass requests to the API without authorization (e.g., DDoS attacks, spam queries, etc.).

5.3. Financial restrictions:

recharging the balance using stolen, counterfeit, or invalid payment methods;
attempting to cash out the balance through third parties, account chains, or transit operations;
any form of money laundering.

5.4. In gaming activities, the following are prohibited:

intentional manipulation of results (upgrades, contracts);
using software to increase chances or distort randomness;
deceiving other users (fake raffles, forged messages, etc.).

5.5. For violations of any of the above points, the platform Administration reserves the right to:

immediately block or restrict access to the account without a refund;
revoke acquired items and transactions;
refuse further service without explanation;
report the violation to relevant authorities and payment systems.

6. SECURITY

6.1. All payment operations are processed through certified payment gateways that comply with international security standards (PCI DSS, SSL, Verified by Visa, MasterCard SecureCode, etc.). The Website does not store or process users' bank card data.

6.2. Data transmission between the User and the server is carried out via a secure HTTPS protocol using Transport Layer Security (TLS) encryption technology.

6.3. The platform employs server-side filters, anti-fraud systems, and behavioral analysis to prevent unauthorized access, DDoS attacks, SQL injections, and other types of digital threats.

6.4. The User bears full responsibility for the security of the accounts used for authorization (Steam, Telegram, VK, Google), passwords, two-factor authentication (if applicable), as well as for all actions performed through their account.

6.5. In case of suspicious activity (e.g., abrupt changes in IP address, multiple failed login attempts, actions indicating hacking), the system may automatically suspend account access and initiate an identity verification process.

6.6. The Administration has the right to:

block the account until the circumstances are clarified;
request supporting documents;
cancel operations conducted in violation of the security policy.

6.7. In the event of account access loss, the User must immediately contact support and provide all necessary data for account recovery (including profile link, registration date, recent transactions, etc.).

6.8. It is forbidden to:

attempt unauthorized access to the Website's functionality;
use third-party scripts, proxies, bots, browser extensions, and emulators;
exploit bugs or vulnerabilities on the platform for personal gain.

6.9. The User is obliged to promptly report any discovered vulnerabilities, errors, or suspicious activity to the Administration without exploiting them, and to await further instructions from the support team.

7. AML POLICY

7.1. The platform adheres to the principles and requirements of international laws and standards for anti-money laundering (AML) and counter-terrorism financing (CFT), including the provisions of the Financial Action Task Force (FATF).

7.2. All platform users commit to using the Website strictly within the bounds of the law. The use of the platform for converting suspicious funds into virtual assets with subsequent withdrawal is strictly prohibited.

7.3. The platform reserves the right to:

conduct User identity verification upon first account top-up, upon reaching a certain transaction threshold, or if suspicious activity is detected;
request identity documents (passport, ID card), proof of source of funds (bank statements, certificates, etc.), and additional information about account activity;
block, restrict, or suspend operations until verification is completed.

7.4. The platform's monitoring system logs all transactions, user actions, and abnormal behavior patterns, including:

multiple attempts to deposit/withdraw without using the funds;
frequent IP address changes, suspicious geographic activity;
operations using fake or stolen payment data;
any form of bypassing limits or restrictions.

7.5. If evidence of possible money laundering or other financial violations is identified, the platform Administration undertakes to:

notify the appropriate authorities or financial partners in accordance with applicable law;
freeze the funds until the investigation is completed;
deny further service and delete the User's account upon confirmation of violations.

7.6. All information obtained in the implementation of the AML policy is processed strictly confidentially, in accordance with the privacy policy and applicable data protection legislation.

8. FINAL PROVISIONS

8.1. This Agreement comes into force upon its publication on the platform and remains in effect indefinitely until revoked or amended by the Administration.

8.2. The platform reserves the right to unilaterally modify, supplement, or remove provisions of this Agreement without prior notice. The updated version is published on the same page and takes effect upon publication.

8.3. Continued use of the platform after changes to this Agreement constitutes the User's automatic acceptance of the new terms. If the User disagrees, they must cease using the Website and delete their account.

8.4. This Agreement is governed by the laws of the jurisdiction in which the company that owns the platform is registered. Until legal details are specified, the parties agree to comply with international standards for online services.

8.5. All disputes, disagreements, or claims arising in connection with this Agreement shall be resolved through negotiations. If no agreement is reached, the dispute shall be submitted to a competent court at the place of the platform's registration.

8.6. This Agreement is drafted in Russian. If other versions exist (including English), the Russian version shall prevail.

8.7. The User may terminate the use of the platform at any time by contacting support to request account deletion. Deleting the account results in the irreversible loss of all data, balance, and acquired items.

8.8. The invalidity of one or more provisions of this Agreement does not affect the validity of the remaining provisions.

9. CONTACTS

9.1. For all questions related to the operation of the Service, you can contact customer support at: support@musor.win.
`,a=`Дата последнего обновления: 18 июля 2026 года

Настоящее Пользовательское соглашение (далее — «Соглашение») регулирует отношения между администрацией сайта musor.win — MUSOR DROP (далее — «Администрация», «Владелец») и любым физическим лицом, использующим данный Сайт и его программные средства (далее — «Пользователь»). Ознакомление с настоящим Соглашением, регистрация и использование функционала Сайта означают полное принятие Пользователем условий настоящего Соглашения.

1. ОБЩИЕ ПОЛОЖЕНИЯ

1.1. Настоящее Пользовательское соглашение (далее — «Соглашение») регулирует отношения между администрацией сайта musor.win — MUSOR DROP (далее — «Администрация», «Владелец») и любым физическим лицом, использующим данный Сайт и его программные средства (далее — «Пользователь»). Ознакомление с настоящим Соглашением, регистрация и использование функционала Сайта свидетельствуют о полном принятии Пользователем условий настоящего Соглашения.

1.2. Сайт musor.win не аффилирован с Valve Corporation и платформой Steam.

1.3. Для использования Сайта требуется авторизация через один из поддерживаемых способов (Steam, Telegram, VK, Google). Регистрация и действия Пользователя осуществляются под его личную ответственность.

1.4. Использование Сайта лицами, не достигшими 18 лет, запрещено.

1.5. Администрация оставляет за собой право изменять настоящее Соглашение в любое время без предварительного уведомления. Актуальная версия публикуется на Сайте.

2. ЛИЧНЫЙ КАБИНЕТ И БАЛАНС

2.1. После авторизации создаётся личный кабинет, в котором отображаются текущий баланс, история операций и доступ к функциям платформы.

2.2. Пополнение баланса доступно через авторизованные платёжные сервисы. Платформа не хранит платёжные данные пользователей.

2.3. Баланс выражается в условных единицах и не является реальной валютой. Он может использоваться исключительно внутри платформы для покупок, апгрейдов, контрактов и участия в розыгрышах.

2.4. Использование баланса означает полное согласие Пользователя с условиями получения и обработки товаров/услуг.

3. ПОКУПКА И ИСПОЛЬЗОВАНИЕ ПРЕДМЕТОВ

3.1. Предметы приобретаются за счёт внутреннего баланса.

3.2. Все покупки считаются окончательными; возврат средств после активации или получения предмета невозможен.

3.3. Вывод предметов осуществляется через API-бота в Steam по трейд-ссылке, указанной Пользователем в личном кабинете.

3.4. Для вывода предметов, приобретённых за счёт средств, зачисленных на баланс, Пользователь обязан совершить игровые действия (ставки, апгрейды, контракты и иные операции, предусмотренные функционалом Сайта) на сумму не менее суммы соответствующего пополнения баланса.

Минимальное требование по отыгрышу применяется к каждому пополнению баланса отдельно и рассчитывается в рамках каждого отдельного пополнения;
При совершении Пользователем нового пополнения баланса соответствующая сумма добавляется к общей требуемой сумме отыгрыша;
До выполнения минимального требования по отыгрышу вывод предметов, обмен или иное извлечение ценности с платформы могут быть ограничены.

4. ВОЗВРАТ СРЕДСТВ

4.1. Возврат средств возможен только при одновременном соблюдении всех следующих условий:

средства были зачислены на баланс, но не использованы (то есть не потрачены на игровые функции, включая покупки, апгрейды, контракты, розыгрыши и т.д.);
с момента пополнения прошло не более 14 календарных дней;
Пользователь инициирует возврат в установленном порядке, включая прохождение верификации.

4.2. Платформа оставляет за собой право отказать в возврате, если:

средства были полностью или частично использованы;
обнаружены признаки нарушения правил платформы;
запрос подан анонимно или без подтверждения личности.

4.3. Для подачи запроса на возврат Пользователь обязан:

обратиться в службу поддержки через канал связи, указанный на Сайте;
предоставить подтверждение платежа (чек, выписку, идентификатор транзакции);
пройти процедуру подтверждения личности (верификация документов и, по запросу, подтверждение владения платёжным средством);
дождаться письменного ответа Администрации (в течение 10 рабочих дней).

4.4. Возврат осуществляется только на тот же платёжный метод, который использовался при исходной операции. Возврат на счета третьих лиц или другие профили не допускается.

4.5. Если Пользователь пополняет баланс, а затем инициирует возврат без законных оснований (например, с целью мошенничества или манипуляции системой), Администрация вправе:

заблокировать аккаунт без возврата остатка баланса;
сообщить о Пользователе платёжной системе для внесения в чёрный список;
уведомить компетентные органы при подозрении на мошенничество.

4.6. Операции с бонусными средствами, промокодами, подарками и кэшбэком возврату не подлежат. Такие средства считаются израсходованными в момент их зачисления.

4.7. В случае технических ошибок (например, двойного списания, сбоя API) Пользователь обязан обратиться в поддержку в течение 72 часов. По результатам проверки средства могут быть полностью возвращены либо баланс восстановлен вручную.

5. ОГРАНИЧЕНИЯ И ЗАПРЕТЫ

5.1. Пользователям запрещено совершать действия, нарушающие технические, правовые и этические нормы платформы. В частности, строго запрещается:

создание и использование более одного аккаунта (мультиаккаунтинг);
передача данных для доступа к аккаунту (логина, пароля) третьим лицам;
использование аккаунтов Steam, не зарегистрированных на имя самого Пользователя;
доступ к платформе через VPN/прокси, подмену IP-адреса или иные способы сокрытия местоположения без предварительного разрешения Администрации;
попытки обхода блокировок, санкций, лимитов или региональных ограничений.

5.2. Запрещены любые попытки вмешательства в работу Сайта, включая:

использование скриптов, ботов, автокликеров, плагинов, прокси-серверов, расширений или стороннего программного обеспечения;
взлом, модификацию или декомпиляцию кода платформы;
использование багов, ошибок или уязвимостей в личных целях;
массовую отправку запросов к API без разрешения (например, DDoS-атаки, спам-запросы и т.д.).

5.3. Финансовые ограничения:

пополнение баланса с использованием украденных, поддельных или недействительных платёжных средств;
попытки обналичивания баланса через третьих лиц, цепочки аккаунтов или транзитные операции;
любые формы отмывания денежных средств.

5.4. В игровой деятельности запрещены:

намеренная манипуляция результатами (апгрейдами, контрактами);
использование программного обеспечения для повышения шансов или искажения случайности;
обман других пользователей (фейковые розыгрыши, поддельные сообщения и т.д.).

5.5. За нарушение любого из вышеуказанных пунктов Администрация платформы оставляет за собой право:

незамедлительно заблокировать или ограничить доступ к аккаунту без возврата средств;
аннулировать полученные предметы и операции;
отказать в дальнейшем обслуживании без объяснения причин;
сообщить о нарушении компетентным органам и платёжным системам.

6. БЕЗОПАСНОСТЬ

6.1. Все платёжные операции обрабатываются через сертифицированные платёжные шлюзы, соответствующие международным стандартам безопасности (PCI DSS, SSL, Verified by Visa, MasterCard SecureCode и др.). Сайт не хранит и не обрабатывает данные банковских карт пользователей.

6.2. Передача данных между Пользователем и сервером осуществляется по защищённому протоколу HTTPS с использованием технологии шифрования Transport Layer Security (TLS).

6.3. Платформа применяет серверные фильтры, антифрод-системы и поведенческий анализ для предотвращения несанкционированного доступа, DDoS-атак, SQL-инъекций и других видов цифровых угроз.

6.4. Пользователь несёт полную ответственность за безопасность своих аккаунтов, используемых для авторизации (Steam, Telegram, VK, Google), паролей, двухфакторной аутентификации (при её наличии), а также за все действия, совершённые через его аккаунт.

6.5. В случае подозрительной активности (например, резкой смены IP-адреса, множественных неудачных попыток входа, действий, указывающих на взлом) система может автоматически приостановить доступ к аккаунту и инициировать процедуру подтверждения личности.

6.6. Администрация вправе:

заблокировать аккаунт до выяснения обстоятельств;
запросить подтверждающие документы;
отменить операции, совершённые с нарушением политики безопасности.

6.7. В случае утраты доступа к аккаунту Пользователь обязан незамедлительно обратиться в поддержку и предоставить все необходимые данные для восстановления аккаунта (включая ссылку на профиль, дату регистрации, последние операции и т.д.).

6.8. Запрещается:

предпринимать попытки несанкционированного доступа к функционалу Сайта;
использовать сторонние скрипты, прокси, боты, браузерные расширения и эмуляторы;
использовать баги или уязвимости платформы в личных целях.

6.9. Пользователь обязан незамедлительно сообщать Администрации о любых обнаруженных уязвимостях, ошибках или подозрительной активности, не используя их, и ожидать дальнейших инструкций от службы поддержки.

7. ПОЛИТИКА AML

7.1. Платформа придерживается принципов и требований международного законодательства и стандартов в сфере противодействия отмыванию денежных средств (AML) и финансированию терроризма (CFT), включая положения Группы разработки финансовых мер борьбы с отмыванием денег (FATF).

7.2. Все пользователи платформы обязуются использовать Сайт строго в рамках закона. Использование платформы для конвертации сомнительных средств в виртуальные активы с последующим выводом строго запрещено.

7.3. Платформа оставляет за собой право:

проводить проверку личности Пользователя при первом пополнении аккаунта, при достижении определённого порога операций или при выявлении подозрительной активности;
запрашивать документы, удостоверяющие личность (паспорт, ID-карту), подтверждение источника средств (банковские выписки, справки и т.д.) и дополнительную информацию об активности аккаунта;
блокировать, ограничивать или приостанавливать операции до завершения проверки.

7.4. Система мониторинга платформы фиксирует все транзакции, действия пользователей и аномальные поведенческие паттерны, включая:

многократные попытки пополнения/вывода без использования средств;
частую смену IP-адресов, подозрительную географическую активность;
операции с использованием поддельных или украденных платёжных данных;
любые формы обхода лимитов или ограничений.

7.5. При выявлении признаков возможного отмывания денежных средств или иных финансовых нарушений Администрация платформы обязуется:

уведомить компетентные органы или финансовых партнёров в соответствии с применимым законодательством;
заморозить средства до завершения расследования;
отказать в дальнейшем обслуживании и удалить аккаунт Пользователя при подтверждении нарушений.

7.6. Вся информация, полученная в рамках реализации политики AML, обрабатывается строго конфиденциально, в соответствии с политикой конфиденциальности и применимым законодательством о защите данных.

8. ЗАКЛЮЧИТЕЛЬНЫЕ ПОЛОЖЕНИЯ

8.1. Настоящее Соглашение вступает в силу с момента его публикации на платформе и действует бессрочно до его отзыва или изменения Администрацией.

8.2. Платформа оставляет за собой право в одностороннем порядке изменять, дополнять или удалять положения настоящего Соглашения без предварительного уведомления. Обновлённая версия публикуется на той же странице и вступает в силу с момента публикации.

8.3. Продолжение использования платформы после внесения изменений в настоящее Соглашение означает автоматическое принятие Пользователем новых условий. В случае несогласия Пользователь обязан прекратить использование Сайта и удалить свой аккаунт.

8.4. Настоящее Соглашение регулируется законодательством юрисдикции, в которой зарегистрирована компания — владелец платформы. До уточнения юридических реквизитов стороны соглашаются руководствоваться международными стандартами в сфере онлайн-сервисов.

8.5. Все споры, разногласия или претензии, возникающие в связи с настоящим Соглашением, разрешаются путём переговоров. При недостижении согласия спор передаётся в компетентный суд по месту регистрации платформы.

8.6. Настоящее Соглашение составлено на русском языке. При наличии иных версий (в том числе на английском языке) преимущественную силу имеет версия на русском языке.

8.7. Пользователь может в любой момент прекратить использование платформы, обратившись в службу поддержки с запросом на удаление аккаунта. Удаление аккаунта влечёт безвозвратную потерю всех данных, баланса и полученных предметов.

8.8. Недействительность одного или нескольких положений настоящего Соглашения не влияет на действительность остальных положений.

9. КОНТАКТЫ

9.1. По всем вопросам, связанным с работой Сервиса, вы можете обратиться в службу поддержки по адресу: support@musor.win.
`,o=e();function s(){let{t:e}=t(),{language:s}=n();return(0,o.jsx)(r,{title:e(`footer.terms`),text:s===`ru`?a:i})}export{s as default};